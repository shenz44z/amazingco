class booking:
    def __init__(self, eid, qty):
        eventId = eid
        eventQty = qty
